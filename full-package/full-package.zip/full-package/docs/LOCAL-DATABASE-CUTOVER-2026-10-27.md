# Local database cutover — October 27, 2026

The production bot now uses SQLite on its existing Linux VM. Supabase is no longer the live state backend. Its existing data is retained as a historical snapshot and is not automatically synchronized.

The service was stopped gracefully before transfer. The source was validated and exported, its inactive lease was checked, and all saved state was copied to a new SQLite database. The destination was compared with the prepared source state and the source was checked again for changes before switching configuration. Running jobs are reset to pending for checkpoint-based recovery. Ranks, cooldowns, tickets, lists, LOA history, queue membership, and configuration are preserved. Resumable tester sessions retain a short startup window.

Verification: 840 players, 137 tickets, 2 leave records, 2,116 saved jobs. SQLite `PRAGMA quick_check` returned `ok`. The service reconnected with an active runtime lease and maintenance disabled. Ten local read samples averaged 8.9 ms; this measures database reads, not full Discord ticket latency. All 167 tests passed on Windows and Linux.

## Backups

- The existing application scheduler saves a validated JSON export daily and retains the ten newest successful automatic backups.
- Backups use the configured `backups.directory`; the live database is `data/lunar.sqlite`.
- A fresh automatic backup was created and decoded successfully after cutover.
- The source export and a fresh local export were copied to the operator PC as separate recovery copies. This is a one-time copy, not scheduled off-VM replication.
- Automatic backups depend on the bot running. VM-local backups do not protect against loss of the VM disk; maintain independent disk backups for that scenario.

## Recovery

Use the normal maintenance and backup restore workflow to recover into SQLite. Preserve the latest local backup before recovery. Do not switch directly back to the retained Supabase snapshot: it no longer contains changes made after cutover.

`scripts/move-to-local-sqlite.mjs --confirm` is a stopped-service transfer utility for Supabase sources. It refuses an active source lease or existing destination file, saves the prior configuration and source export privately, validates and compares the copy, then atomically saves the backend configuration. It does not delete or alter the Supabase source. A failed destination can remain on disk for inspection; review failures before removing it.

There is no automatic remote fallback, avoiding two diverging live databases. The bot now depends on its VM disk and Discord connectivity rather than Supabase availability. Existing Supabase organization usage must still be managed separately: this switch cannot undo past metered usage or stop other clients using that organization.
