# Ticket speed work — October 26, 2026

The user requested faster ticket handling after observing long closure delays. The changes below preserve transcript-first deletion and durable jobs.

## Changes

- Archive jobs receive the same priority as ticket opening, while keeping one worker slot available for foreground work.
- Result posting/reactions have an independent job ordering key, so a slow results-channel delivery cannot hold the ticket archive open. Result delivery remains durable after closure.
- Concurrent state mutations are grouped, in order, into one CAS write (up to 32 per group). Each mutation uses an isolated draft. A failed mutation is rolled back independently; successful operations resolve only after the shared commit succeeds. External CAS conflicts replay the batch against fresh state.
- Existing channel overwrites are locked in one Discord request, preserving visibility and the bot's access. Confirmed stale-target failures use the existing per-target fallback; permission/transient failures remain retryable.
- Ordinary gateway, worker polling and periodic-cycle reads skip the separate lease-document lookup. The dedicated lease watchdog continues renewing and enforcing expiry; explicit ownership checks still read the lease.
- Large Supabase state documents use a versioned deflate/base64 envelope. Small records, including heartbeat state, remain plain. The reader accepts both legacy and compressed data; backups/exports remain ordinary uncompressed bot-state JSON. Decompression has a 64 MiB output bound, and larger writes are rejected before storage.
- The live configuration's additional delay after a confirmed archive upload is zero. Active tickets' delay snapshots were updated with a backup saved first. Deletion still waits for all transcript/evidence work and archive publication to succeed.

## Measured results

These are individual private bot-only rehearsals on the home VM with the existing Supabase/Discord deployment, not percentile guarantees. No human/role notifications were sent, and temporary artifacts were removed.

| Version | Opening | Archive and deletion |
| --- | ---: | ---: |
| Prior audit rehearsal | 26.192 s | 48.150 s |
| Batching/priority/bulk lock, zero extra delay | 19.828 s | 28.418 s |
| Plus compressed remote state | 12.717 s | 13.600 s |
| Final version, avoiding redundant lease reads | 12.677 s | 10.329 s |

Final closure was about 79% shorter than the prior rehearsal; opening was about 52% shorter. Each rehearsal confirmed the transcript attachment before source deletion. Final maintenance was off, the lease renewed, and no unfinished jobs remained.

A representative state was 1,027,130 bytes logically and 294,488 bytes in compressed storage (about 71% smaller). Before compression, two measured full-state commits took 1,269 ms and 2,611 ms; one subsequent compressed commit took 366 ms. These samples are not guarantees about total Supabase disk I/O or all request latency. Revision-only idle polling remains in place.

The 5,000-player, 5,000-historical-job, 1,000-player-queue and ten-concurrent-reservation load check passed on Windows and Linux. Windows reservations measured 482 ms; Linux reservations measured 289 ms. Both platforms passed 164 regression tests, including batch conflict replay, failure isolation, compression/restart compatibility, explicit lease reads, single-request locking, result/archival concurrency, and zero-delay transcript-first deletion.

## Recovery and limits

A normal current-version restore reads existing backup JSON and writes the appropriate storage format automatically. Before rolling back to a runtime from before compression support:

1. Stop the bot service.
2. Run `node --env-file=.env scripts/restore-plain-supabase-state.mjs --confirm` from the VM app directory using its supported Node runtime. The tool refuses an active lease, saves a local backup, uses revision CAS and verifies the decoded state.
3. Only then install/start the older runtime.

Do not start an older runtime directly against the compressed row. Direct SQL/dashboard consumers of `crystal_state.body` must account for the versioned envelope; legacy source tables are unchanged. The fallback helper does not modify credentials or change table policies.

Supabase and Discord latency/rate limits still affect speed. The main domain state is still a whole-document CAS, now with batching and compression; sustained much higher traffic eventually calls for normalized state storage. Historical ranks, cooldowns, audit records and completed jobs were not deleted to obtain this improvement. Very long transcript assembly still uses memory.
