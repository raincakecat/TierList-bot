# Reliability audit — October 26, 2026

This audit reviewed the failure paths behind ticket closure delays, database bandwidth, disk I/O, and offline recovery. It covers the private bot's storage adapters, runtime and systemd lifecycle, worker scheduling, Discord ticket/panel messages, transcripts, LOA notifications, quota reporting, and backup recovery. It is a reliability review, not a guarantee against provider outages or a separate security penetration test.

## Fixes

| Verified failure path | Change |
| --- | --- |
| A hanging database request could outlive the confirmed runtime lease. | Database HTTP requests have a 15-second abort deadline. A separate lease watch stops the process if the last confirmed lease expires, even when renewal is hanging. Only one renewal is in flight. |
| Startup validation and shutdown could run without renewing the lease. | Renewal begins immediately after acquisition, before Discord setup, and remains active while existing jobs drain on shutdown. Startup failures clean up and exit nonzero. |
| Five failed starts in five minutes could permanently exhaust service restart attempts. | The dedicated bot unit no longer stops retrying because of that rate limit; restart delay remains 15 seconds. |
| Temporary Discord member lookup failures could silently complete role jobs without assigning roles. | Only confirmed missing members/users are ignored; temporary and permission failures remain retryable. |
| Temporary panel fetch errors could create duplicate panels; concurrent refreshes could both create a new panel. | Only Unknown Message causes recreation, and updates to each panel key are serialized. |
| Restored tickets and access/type-change messages could fail on uncached Discord IDs. | Permission overwrites carry explicit member/role types. |
| A type-change notification could ping the same role repeatedly after a later step failed. | The role ping has its own durable delivery checkpoint and nonce. |
| Obsolete access/rename/type notices could delay closing tickets. | These obsolete actions are skipped after closure starts. |
| A long transcript could exceed the single-file upload cap and never complete closure. | Large transcripts are split into numbered UTF-8-safe parts. Every part is checkpointed, and deletion waits until all parts are posted. |
| A restored transcript checkpoint could reference a missing local file. | The transcript is regenerated from the retained ticket channel before archival proceeds. |
| Retry failures did not retain useful diagnostic codes. | Safe error codes and times are saved; private health reports expose retry causes and state size. Raw error messages and credentials are not persisted. |
| Large monthly quota reports could exceed Discord's message length. | Reports use deterministic, mention-preserving pages and do not repost after restart. |
| LOA edits still added a visible internal reference footer. | That footer is removed; durable delivery recovery remains. |

The earlier fixes for separate small heartbeat writes, revision-only unchanged polling, departed-member archival, and scheduled safety delays remain in place and are covered by the regression suite.

## Validation

Regression coverage includes request timeout/cancellation, hanging and failed renewal, single renewal flight, lease preservation during restore, transient member/panel failures, concurrent panel creation, uncached overwrite payloads, repeat-ping recovery, UTF-8 transcript splitting, multipart upload interruption/retry, missing local transcripts, obsolete notices, private diagnostics, and large quota reports.

The repeatable local SQLite load check passes with 5,000 players, 5,000 completed jobs, 1,000 queued players, and ten concurrent reservations. The queue uses eight pages; the saved state is 1,608,380 bytes. The measured Windows run seeded in 48 ms, reserved ten distinct FIFO players in 642 ms, and read the state in 12 ms. These are local measurements, not Discord or Supabase response-time guarantees.

Linux regression, load-check and private live rehearsal results are recorded with the deployment verification below.

## Remaining practical limits

- Supabase usage already accumulated in the billing period is not reset by these changes. Provider outages, quotas and throttling remain outside the bot's control.
- Domain writes still use a whole-state CAS document. Revision-only reads and a separate heartbeat remove unnecessary transfer/write amplification, but substantially larger activity/history will eventually require normalized state storage. This audit does not delete historical player, rank, audit or job data.
- Discord rate limits, removed permissions, deleted archive channels and missing evidence can intentionally leave work pending rather than delete unsaved tickets. Private health and operational reports identify those failures.
- Large transcripts are still assembled in memory. Splitting fixes the attachment cap; it does not make arbitrarily large ticket histories free of memory cost.
- Fault injection runs in isolated tests. The audit does not deliberately disable the production database or interrupt active staff tickets.

## Deployment verification

- 156 regression tests passed on both Windows and Linux with Node v24.18.0.
- Linux local load check: the same 5,000 players/5,000 jobs/1,000 queued players/ten reservations passed; seed 23 ms, reservations 299 ms, read 8 ms.
- Live private bot-only rehearsal passed on the existing VM/Supabase/Discord deployment. Request-to-open measured 26,192 ms; archival plus safe deletion measured 48,150 ms. The archive attachment was fetched and confirmed before channel deletion. These timings include transport/provider latency and are measurements, not speed guarantees.
- No human or role notifications were sent. Temporary ticket, archive channel, local audit transcript, test profile and ticket-specific jobs were removed afterward.
- Maintenance remained disabled, the runtime lease renewed, and the saved-job backlog was empty at completion.
- The installed service reports active, automatic restart enabled, and `StartLimitIntervalUSec=0`.
- A pre-deployment state backup and previous runtime/service copies are retained privately on the VM for recovery.
