# TierList Bot

Configurable Discord bot for regional tier testing, account linking, support tickets, restrictions, and backups. One application can serve a nine-mode testing server and a separate support server through one database.

Version 0.2.0 adds staff Leave of Absence requests, approval controls, timed roles, notifications, and quota exemptions.

**Full package:** [Download the ZIP with compiled files and PDF setup guide](full-package/full-package.zip), or [read the PDF guide](docs/Full-Setup-Guide.pdf).

**Status:** This repository contains the reusable bot source, examples, and setup guide. Supply your own server IDs and credentials. See `docs/STATUS.md` for feature and test coverage.

## Install the ready-to-run ZIP

1. Install Node.js **24.17.0 or newer** on Windows, Linux, or macOS.
2. Extract the ZIP into its own directory. Open a terminal in that directory.
3. Run `npm ci --omit=dev` to install the pinned runtime dependencies.
4. Copy `config.example.json` to `config.json`, and `.env.example` to `.env`.
5. Set `community.guildId` to your server ID as a quoted string. Set `DISCORD_TOKEN` in `.env`.
6. Choose a database. Supabase is the example default; follow the database instructions below. Never commit `.env` or your live configuration.
7. Choose cooldowns explicitly: `"0"` means none, or use values such as `"7d"`. Disable quotas or choose a monthly quota. Enable only the modules and regions you need.
8. Put the bot's role above every role it will assign. Enable **Server Members**, **Message Content**, and **Presence** privileged intents in the Discord Developer Portal. Invite with `bot` and `applications.commands` scopes and the permissions described below.
9. Run `npm start`. A Discord administrator opens `/setup wizard` to choose settings and resource mappings, then reviews the attached draft and confirms. `/setup preview` and `/setup apply` remain available. You can supply existing resource IDs, create missing ones, or combine both. Setup saves each successful creation to `config.json`.
10. Run `/config validate`. Fix reported problems before publishing panels or opening tests. `/panels refresh` updates the configured panels.

Normal operation requires Manage Channels, Manage Roles, View Channel, Send Messages, Read Message History, Attach Files, Embed Links, Add Reactions, Mention Everyone (for the agreed regional announcement), and Manage Messages (pinning opening messages). Grant these in the appropriate channels. The bot never needs a personal Discord account token.

## Database options

- **Supabase:** run `sql/supabase.sql` once in your own project's SQL editor. Set `SUPABASE_URL` and the server-only `SUPABASE_SERVICE_ROLE_KEY` in `.env`. The state table uses RLS and does not allow anonymous/authenticated API clients. Use a dedicated project for the bot.
- **PostgreSQL:** set `database.backend` to `postgresql` and set `DATABASE_URL` in `.env`. The connection's account needs permission to create the private `crystal` schema and its state table. Configure TLS in the connection settings for remote databases; do not disable certificate verification.
- **SQLite:** set `database.backend` to `sqlite`. The local file defaults to `data/crystal-bot.sqlite`. Use a local disk rather than a shared network filesystem. Node's built-in SQLite module may print its experimental warning on Node 24.

One process can serve several guilds through `BOT_CONFIGS`, with one configuration file per guild and a shared database. A database lease prevents simultaneous bot processes. An unclean shutdown may require waiting up to 60 seconds before restart.

The first persistence implementation stores a versioned community state document with atomic revision updates. This keeps all account, queue, ticket, and job changes consistent across backends. It is intended for one community per instance; large-scale data growth needs performance measurement before release. Archived channel messages live in transcript files, not in the state document.

## Configuration changes

Edit the local JSON file and run `/config reload`. The bot checks the new file and Discord resources before changing the active configuration. Database/server changes require stopping the bot and a reviewed transfer. Resource mapping and feature changes require maintenance. Old tickets keep their saved access roles and archive channel. Disabling creation does not remove existing tickets.

Neutral branding and messages are editable through documented `{placeholders}`. Normal and high cooldowns can be disabled explicitly; quotas have their own module switch. NA/EU/AS can be enabled individually. The tier-list module requires all five list channels.

The private `/setup wizard` edits a draft until confirmation. Its screens cover community name/timezone, modules/regions, cooldowns/quota/capacity, and role/channel/category IDs. Blank resource mappings request creation. Drafts expire after 15 minutes; confirmations after 5 minutes. On initialized installations it requires Owner and maintenance before applying. Database credentials and the initial server ID remain host-side. Custom support policies and templates remain editable in JSON.

`/health` is private to Bot Admin/Owner and reports database connectivity, uptime, recovery fencing, maintenance, saved jobs, the last successful automatic backup, and configuration problem counts. It omits credentials and raw backend errors. Legacy jobs without a creation timestamp use their scheduled time for the oldest-work indicator.

Staff activity notices are optional. Enable `activity.enabled` and configure separate `activity.noticeChannelId` and `activity.reportChannelId` channels; setup can create missing channels. High Staff, Bot Admins and Owners can run `/activity start`. Staff have 24 hours from posting to respond. The private report lists nonresponders and staff with the LOA role separately, excluding staff who left or lost their staff role. A saved notice resumes after a restart; roster or permission failures are retried and reported to the operational log. Discord administrators can see private channels as a consequence of Discord permissions.

`activity.exemptRoleIds` optionally lists additional role IDs exempt from activity checks. Roles are checked when the notice closes, including for notices already running; exempt staff appear separately from missing staff in the private report.

`/cooldown` privately shows your cooldown for each game mode. Map `staffDashboard.channelId` to a dedicated channel visible only to Staff and High Staff for a dashboard showing ticket, queue, tester, pending LOA, and retry counts. It refreshes about once a minute. Discord Administrators retain their normal access to private channels.

`/testerstats` shows passed evaluations separately alongside completed-test counts, crediting the staff member who used `/passeval`. Existing saved evaluation audit records are included when their ticket is available. Quotas and leaderboards continue to use completed-test counts.

## Testing and support

Verification validates an account's existence and UUID, then links it to the Discord player. It is not proof of Minecraft account ownership. Rank/history stay with the Discord ID after staff unlink an account.

Normal queue tests open in regional categories. `/passeval` records LT3 and moves the ticket to HT3 testing. HT3/LT2/HT2/LT1 players request the next high tier directly. Staff close tests with a tier or Test Discontinued. Previous Rank is captured when the ticket opens. HT3 list entry is manual; LT2, HT2, and LT1 list entry is automatic. HT1 ranks/tests remain supported without a dedicated HT1 list.

Support includes five configurable defaults and custom types. Type-specific access applies even in overflow categories. Opening messages are pinned. Only responsible staff can use the close button. Every enabled ticket type requires an archive channel.

## Staff leave of absence

Enable `modules.loa` in the setup wizard or configuration. Map `loa.roleId`, `permissionGroups.loaAdmin`, and `channels.requestLoa`, `loaInProgress`, and `acceptedLoa`. Setup creates missing resources. The LOA role must be separate from permission/tier/region/waitlist roles. Request LOA and Accepted LOA are Staff/LOA Admin/Owner visible; LOA In Progress is private to LOA Admin/Owner. Review privacy on supplied existing channels.

The Request LOA channel contains a branded portal/button and an automatically updated Members on LOA roster with return dates. Colors, community branding/icon, and `templates.loaPanel` are configurable. The roster paginates and removes obsolete pages. Staff submit username, whole-day duration `1d`–`30d`, and reason. One pending or active request is allowed per Discord member; the username is descriptive and does not change Minecraft linking.

LOA Admins/Owners accept or deny in the private review channel. Denial requires a reason. Approval starts the timer, grants the LOA role, and posts to Accepted LOA. Decisions cannot be applied twice. Requesters receive approval/denial/expiry/early-end DMs; blocked DMs are recorded privately without reversing decisions.

Requesters can withdraw pending requests or end their leave early through buttons or `/loa status`. LOA Admins use `/loa end member reason`. Expiry removes the role automatically, including after restart or disabling new requests. Active leave is restored on rejoin; expired leave is not restored. Existing leave keeps its saved role and channel mappings.

Any approved leave overlapping a month exempts that tester from the entire month's quota. Early termination uses actual leave time. Counts/leaderboards remain unchanged, active sessions are not stopped, and `/start` remains available. Historical leave is retained in backups for quota reporting. No future-start scheduling or extensions are included.

## Archives and recovery

Closure locks the channel and saves work in a durable queue. Required transcript/image archival must succeed before deletion. Failed operations remain saved and retry with backoff; the operational log reports failures. Result posts use saved message IDs and Discord nonces to recover from uncertain sends, without visible logging references.

Images from reports/appeals are copied by default, videos are not copied, and YouTube/attachment links remain in Markdown transcripts. Images are stored privately under `data/archives`, removed after the configured retention (default ten days), and must be accessed through authorized host access. Transcripts have no automatic expiry. Do not serve the archive folder publicly.

Current evidence limits are **25 MiB per copied image** and **multipart Markdown transcripts (7 MiB chunks for large exports)**. Oversized/failed required archives retain the channel for staff intervention. These limits need testing against your server's expected ticket volumes.

Daily portable database backups retain the latest ten successful automatic backups. Manual exports are not automatically removed. Host backups do not copy local evidence files: back up the archive directory separately if you need disaster recovery for evidence.

Owner commands: `/backup export`, `/backup restore`, `/backup transfer`. Restore/transfer require maintenance, a preview, and confirmation. Transfer writes to an empty destination, verifies its state, and keeps the source in maintenance. Stop the source process before switching configuration and starting the destination. Backups exclude credentials and runtime leases.

Restore and transfer fence new state-changing operations and wait up to 30 seconds for active jobs/actions to finish before recovery begins. Process lease renewal continues. A waiting timeout starts no recovery and leaves maintenance enabled; retry with a new confirmation after resolving long-running work. Restoring state does not undo external Discord messages or deleted channels.

## Optional migration

Enable the migration module and place a standardized JSON file in `data/imports`. See `docs/MIGRATION.md`. Use `/migration preview`, correct blocking issues, then `/migration apply` in maintenance. The import is one-time; `/migration retry` reschedules saved failed operations without repeating successful database imports. Stop the old bot/database writers before any live takeover.

## Develop from source

Run `npm ci`, `npm test`, then `npm run package`. The ZIP contains compiled runtime files, not local credentials, configuration, databases, or archives. `npm run validate` checks the local configuration without connecting to Discord.

GitHub Actions builds/tests on Windows and Linux and verifies a clean full-package installation. Run `node scripts/load-check.mjs` after building for the repeatable SQLite volume/concurrency check. See [load measurements](docs/LOAD-CHECKS.md), [command permissions](docs/COMMANDS.txt), [live Discord rehearsal](docs/LIVE-REHEARSAL.md), and [remote database rehearsal](docs/DATABASE-REHEARSAL.md). Live checks remain pending until test infrastructure is provided.

The source repository is public. Production credentials and live configuration belong only on the host and are excluded by `.gitignore`. No project license has been selected.

## Linux / PM2

From the extracted directory, install PM2 if desired and run `pm2 start dist/src/main.js --name crystal-bot --node-args="--env-file=.env"`. Set the working directory to the installation folder. Use one process, preserve its `data` directory during updates, and enable startup using PM2's instructions for your Linux distribution. Run configuration validation and create a manual backup before updating.

## Documentation sources

Runtime conventions follow the [discord.js documentation](https://discord.js.org/docs/packages/discord.js/main), [Node.js SQLite documentation](https://nodejs.org/api/sqlite.html), [Supabase RPC documentation](https://supabase.com/docs/reference/javascript/rpc), and [Supabase RLS documentation](https://supabase.com/docs/guides/database/postgres/row-level-security). Dependency versions are pinned in `package-lock.json`.

## Recent updates

- Opening a regional queue posts one plain regional waitlist-role mention in the waitlist channel. It stays until that queue closes; joining additional testers does not send another ping.
- Ticket names use Discord account usernames. Creation confirmations include a channel link.
- `/requestclose reason timeout` lets the opener accept or deny; pending requests close automatically after 1h–7d. `/forceclose reason` is for responsible support staff and still requires archival.
- `/maketestticket member tester` registers an existing channel as a test ticket.
- Optional `permissionGroups.cdResetter` grants only `/resetcooldown`, without other Bot Admin powers.
- `ticketNotifications` can override high-test and support opening role pings without granting access.
- Departed members are removed from published tier lists while player history remains saved.
- Remote state uses compression, revision-only polling, batched commits, separate small runtime leases, and bounded requests. SQLite on a single VM avoids remote bandwidth dependence; keep independent backups.

See [release notes](docs/UPDATES-2026-10-28.md) and [commands](docs/COMMANDS.txt).

Owner bulk tools: `/purgehightests start reason:...` previews and confirms a durable transcript-first purge, including overflow and recognized legacy high-test channels. `/purgehightests status` reports progress. `/allcdreset` confirms a global cooldown reset. Neither command is granted by Bot Admin or CD Resetter alone. Testers can join normal queues after verification and waitlist entry.

Fight template sections run from highest tier to lowest; see [format ordering](docs/FIGHT-TEMPLATES.md).

Missing permission roles now block only the request flows that need them; unrelated missing staff roles no longer stop testing. See [request readiness](docs/REQUEST-READINESS.md). Other configuration/permission failures still block requests.

`/ticketclose reason:...` force-closes the current support ticket as an alias for `/forceclose`. Responsible closing staff or Owner authorization is required, and the transcript must save before channel deletion.

## Multiple servers and game modes

The candidate supports a shared bot/database with isolated community and mode records. See [multi-server setup](docs/MULTI-SERVER.md) and `config.multimode.example.json`. Keep the new community in maintenance until live rehearsal passes.

For the consolidated layout, start from `config.consolidated.example.json`. The main server hosts Crystal, Sword, Axe, SMP, Pot, Mace, UHC, Nethpot, and Spear Mace. Each mode has NA, EU, and AS/AU waitlist channels under three regional queue categories. One High Testing Lists forum holds a post per mode, and all modes share one results channel. The support server handles General Support, Player Reports, Staff Reports, Restriction Appeals, and Partnership Requests. Existing tickets in an old server can finish there while new requests use the support server.

`/profile` shows ranks for every mode in either server. `/addtester` and `/stoptester` change only the selected mode's Tester role. The support server mirrors configured staff and tester roles from the main server through `roleSync`; it does not need tier roles. Every mode-specific Tester role grants the shared Staff role in both servers, including existing members and manually assigned testers. The support Tester title grants Staff access, while Ticket Support pings normal support tickets. Staff Reports use a separate Manager-and-above access group. `scripts/enable-tester-staff.mjs` adds the tester roles to both servers' staff-title mappings, with a dry run by default and `--apply` for a backed-up update.

The main server uses rank-colored trophy role icons for HT1, LT1, HT2, LT2, HT3, and LT3 across all nine game modes. HT4, LT4, HT5, and LT5 have no role icon. The source PNGs are in `branding/role-icons/`; `scripts/apply-rank-role-icons.mjs` previews the target roles and applies the icons with `--apply`. `scripts/remove-support-tier-roles.mjs` removes the 90 support tier-role mirrors, their sync mappings, and saved grants after checking channel permissions. Stop the bot before running that cleanup; both scripts create private backups under `data/` when applied.

Set `channels.migrations` in the main server to a public, read-only `#migrations` channel. `/migrate` is available to Regulator and above in the support server; it requires the target mode, tier, region, and source. The rank changes in the main server and its announcement goes to `#migrations`. Normal testing results continue in `#results`.

In the support server, Regulator and above can use `/resetcooldown member:@player mode:Sword` to clear that player's cooldown in one main-server game mode. Other modes retain their cooldowns.

Set `BOT_CONFIGS` to the main config, any retiring server config, and the support config in that order. Use the same database settings in all files. Set `supportRequestsEnabled: false` and `supportRedirectUrl` in a retiring server to replace its support panel with a link. Set `supportTargetGuildId` in the support config so authorized support staff can inspect the main server profile and remove a restriction. Never commit live config files, `.env`, database files, transcripts, or deployment IDs.

Queue opening requires Staff, Verified Tester, and the selected mode's Tester role. Staff can handle an assigned ticket without that mode role. Title roles can grant the shared Staff or High Staff role automatically through `staffTitles`; High Staff includes Overseer and above, while Partnership Manager is Staff but below Regulator. Support ticket visibility is set by each channel's permission overwrites; assigning a title alone does not bypass private channel rules.

## Tester and staff guides

Role-specific command references are in [Tester guide](docs/TESTER-GUIDE.md), [Staff guide](docs/STAFF-GUIDE.md) and [High Staff guide](docs/HIGH-STAFF-GUIDE.md). They describe the required roles, examples and when each operation is appropriate.

To publish or update read-only Discord guide channels for a configured multi-mode server, build from source first (the full package already includes the compiled runtime), then run:

```sh
node --env-file-if-exists=.env scripts/publish-guides.mjs data/configs/other-modes.json --apply
```

Omit `--apply` for a preview. The publisher reuses suitable existing guide channels, pins a contents page, edits its own saved messages on updates and restricts channel visibility by role. Guide visibility does not grant command permissions. Its private channel/message manifest is saved under `data/guides/`; keep that directory with the host configuration, outside Git.
