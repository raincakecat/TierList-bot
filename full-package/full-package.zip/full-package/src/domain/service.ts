import { randomUUID } from 'node:crypto';
import { milliseconds, type Config } from '../config.js';
import { allowed, requireGroup, rolesFor } from './permissions.js';
import { REGIONS, TIERS, UserError, type Actor, type Job, type Player, type Region, type State, type Ticket, type Tier } from './types.js';
import type { Store } from '../storage/store.js';

export const highTarget:Partial<Record<Tier,Tier>>={HT3:'LT2',LT2:'HT2',HT2:'LT1',LT1:'HT1'};
export const listTiers:Tier[]=['HT3','LT2','HT2','LT1'];
export function player(s:State,id:string):Player {
  return s.players[id]??(s.players[id]={id,tier:'Unranked',uuid:null,ign:null,region:null,preferredServer:null,waitlist:false,cooldownUntil:0});
}
export function enqueue(s:State,kind:Job['kind'],data:Job['data'],now:number,id:string=randomUUID()):string {
  if(kind==='queues'||kind==='lists'){const existing=Object.values(s.jobs).find(j=>j.kind===kind&&j.status==='pending');if(existing){existing.nextAt=Math.min(existing.nextAt,now);return existing.id;}}
  s.jobs[id]??={id,kind,data,status:'pending',attempts:0,nextAt:now,createdAt:now,checkpoints:{}};return id;
}
export function restricted(s:State,p:Player,now:number):boolean{return s.restrictions.some(r=>(r.playerId===p.id||r.uuid===p.uuid)&&(r.until===null||r.until>now));}
export function currentTicket(s:State,id:string):Ticket|undefined{return Object.values(s.tickets).find(t=>t.opener===id&&t.type==='test'&&t.status!=='closed');}
export function removeQueue(s:State,id:string){for(const r of REGIONS)s.queues[r]=s.queues[r].filter(x=>x!==id);}
export function clearLists(s:State,id:string){for(const tier of [...listTiers,'HT1'] as Tier[])for(const r of REGIONS)if(s.lists[tier]?.[r])s.lists[tier]![r]=s.lists[tier]![r]!.filter(x=>x!==id);}
export function syncLists(s:State,p:Player,now:number){clearLists(s,p.id);if(listTiers.includes(p.tier)&&TIERS.indexOf(p.tier)>=TIERS.indexOf('LT2')&&p.region&&p.uuid&&!restricted(s,p,now)){s.lists[p.tier]??={};(s.lists[p.tier]![p.region]??=[]).push(p.id);}}
export function tierName(t:Tier):string{return t==='Unranked'?t:`${t[0]==='L'?'Low':'High'} Tier ${t[2]}`;}
export function channelName(v:string):string{return v.toLowerCase().replace(/[^a-z0-9_-]/g,'-').slice(0,90)||'ticket';}

export class Service {
  constructor(public store:Store,private getConfig:()=>Config,private clock:()=>number=Date.now){}
  get config(){return this.getConfig();}
  private ensure(s:State){if(!s.initialized)throw new UserError('An administrator must finish setup first.');if(s.maintenance)throw new UserError('The bot is currently in maintenance.');}
  private testing(s:State){this.ensure(s);if(!this.config.modules.testing)throw new UserError('Testing is disabled.');}
  private region(input:string):Region{if(!REGIONS.includes(input as Region)||!this.config.regions[input as Region].enabled)throw new UserError('Choose an enabled region.');return input as Region;}
  private eligible(s:State,p:Player,now:number,bypass=false){
    if(!p.uuid||!p.region)throw new UserError('Verify your Minecraft account first.');
    this.region(p.region);if(restricted(s,p,now))throw new UserError('Testing is restricted for this account.');
    if(currentTicket(s,p.id))throw new UserError('You already have an open testing ticket.');
    if(!bypass&&p.cooldownUntil>now)throw new UserError(`Your cooldown ends <t:${Math.floor(p.cooldownUntil/1000)}:R>.`);
  }
  private audit(s:State,a:Actor,action:string,target:string,now:number){s.audit.push({id:randomUUID(),actor:a.id,action,target,at:now});}
  private jobs(s:State,p:Player,now:number){enqueue(s,'roles',{playerId:p.id},now);enqueue(s,'lists',{},now);enqueue(s,'queues',{},now);}
  private open(s:State,p:Player,tester:string|null,target:Tier|null,now:number):Ticket {
    const c=this.config,r=p.region!;
    const openingLists=listTiers.flatMap(tier=>REGIONS.filter(region=>s.lists[tier]?.[region]?.includes(p.id)).map(region=>({tier,region})));
    const t:Ticket={id:randomUUID(),channelId:null,type:'test',opener:p.id,region:r,openingTier:p.tier,openingIgn:p.ign,tester,target,passed:false,status:'opening',participants:tester?[tester]:[],openedAt:now,
      accessRoles:rolesFor(c,['staff','owner']),closingRoles:rolesFor(c,['staff','owner']),archiveChannelId:c.channels.testingArchives!,copyImages:false,imageRetentionDays:c.archival.imageRetentionDays,
      categoryId:target?c.categories.highTests!:c.regions[r].testCategoryId!,name:channelName(target?`${p.ign}-${target}-${r}`:`test-${p.ign}-${r}`),openingLists,
      openingUuid:p.uuid,preferredServer:p.preferredServer,previousTestAt:Math.max(p.previousTestAt??0,...Object.values(s.tickets).filter(t=>t.opener===p.id&&t.type==='test'&&t.status==='closed'&&TIERS.includes(t.outcome as Tier)).map(t=>t.closedAt??0))||null,archiveDirectory:c.archival.directory,minimumDeletionDelaySeconds:c.archival.minimumDeletionDelaySeconds};
    s.tickets[t.id]=t;if(target)removeQueue(s,p.id);enqueue(s,'open',{ticketId:t.id},now);enqueue(s,'queues',{},now);return t;
  }
  async verify(a:Actor,account:{uuid:string;ign:string},region:string,server:string){
    const now=this.clock(),r=this.region(region);
    if(!/^[a-f0-9]{32}$/i.test(account.uuid)||!/^\w{1,16}$/.test(account.ign)||!server.trim()||server.length>100)throw new UserError('Invalid account or preferred server.');
    return this.store.change(s=>{this.testing(s);const p=player(s,a.id);if(p.uuid)throw new UserError('Your account is already verified. Ask staff to unlink it if necessary.');if(currentTicket(s,p.id))throw new UserError('Finish your open test first.');
      if(Object.values(s.players).some(x=>x.uuid===account.uuid.toLowerCase()&&x.id!==p.id))throw new UserError('This Minecraft account is already linked.');
      Object.assign(p,{uuid:account.uuid.toLowerCase(),ign:account.ign,region:r,preferredServer:server.trim()});syncLists(s,p,now);this.jobs(s,p,now);this.audit(s,a,'verify',p.id,now);return p;});
  }
  async waitlist(a:Actor){const now=this.clock();return this.store.change(s=>{this.testing(s);const p=player(s,a.id);this.eligible(s,p,now);p.waitlist=true;enqueue(s,'roles',{playerId:p.id},now);
    if(p.tier==='HT1')return 'make a general support ticket to address rank defenses or retirement';
    const target=highTarget[p.tier];if(target){this.open(s,p,null,target,now);return 'Your high testing ticket is being opened.';}return `You now have access to the ${p.region} waitlist. Use Join Queue there.`;});}
  async join(a:Actor,region:string){const now=this.clock(),r=this.region(region);return this.store.change(s=>{this.testing(s);const p=player(s,a.id);this.eligible(s,p,now);if(p.region!==r||!p.waitlist)throw new UserError('Enter your registered region’s waitlist first.');
    if(REGIONS.some(x=>s.queues[x].includes(p.id)))throw new UserError('You are already queued.');
    if(highTarget[p.tier]||p.tier==='HT1')throw new UserError('Use Enter Waitlist for your high-tier test.');
    const testers=Object.keys(s.testers).filter(id=>s.testers[id]===r);if(!testers.length)throw new UserError('No testers are active for this region.');if(s.queues[r].length>=this.config.testing.queueCapacityPerRegion)throw new UserError('This queue is full. Try again later.');
    s.queues[r].push(p.id);enqueue(s,'notice',{channelId:this.config.channels.testerAlerts,content:`${testers.map(id=>`<@${id}>`).join(' ')}\nA user <@${p.id}> has joined the ${r} queue!`,mentions:[...testers,p.id]},now);enqueue(s,'queues',{},now);return s.queues[r].length;});}
  async departed(id:string){const now=this.clock();return this.store.change(s=>{
    s.departures??=[];if(!s.departures.includes(id))s.departures.push(id);removeQueue(s,id);clearLists(s,id);
    const region=s.testers[id];delete s.testers[id];if(region&&!Object.values(s.testers).includes(region))s.queues[region]=[];
    enqueue(s,'queues',{},now);enqueue(s,'lists',{},now);
  });}
  async leave(a:Actor){return this.store.change(s=>{this.ensure(s);removeQueue(s,a.id);enqueue(s,'queues',{},this.clock());});}
  async start(a:Actor,region:string){requireGroup(this.config,a,'verifiedTester');requireGroup(this.config,a,'staff');const r=this.region(region),now=this.clock();return this.store.change(s=>{this.testing(s);if(s.testers[a.id])throw new UserError('Use /stop before starting another session.');const first=!Object.values(s.testers).includes(r);s.testers[a.id]=r;player(s,a.id).testerSince??=now;if(first){(s.lastTestingSession??={})[r]=now;enqueue(s,'notice',{channelId:this.config.regions[r].queueChannelId,content:'@here',here:true,region:r,sessionAt:now},now);}enqueue(s,'queues',{},now);});}
  async stop(a:Actor){requireGroup(this.config,a,'verifiedTester');return this.store.change(s=>{this.ensure(s);const r=s.testers[a.id];delete s.testers[a.id];if(r&&!Object.values(s.testers).includes(r))s.queues[r]=[];enqueue(s,'queues',{},this.clock());});}
  async next(a:Actor){requireGroup(this.config,a,'verifiedTester');requireGroup(this.config,a,'staff');const now=this.clock();return this.store.change(s=>{this.testing(s);const r=s.testers[a.id];if(!r)throw new UserError('Use /start first.');const id=s.queues[r].find(id=>!currentTicket(s,id));if(!id)throw new UserError('The queue is empty or its remaining tickets are opening.');const p=player(s,id);this.eligible(s,p,now);return this.open(s,p,a.id,null,now);});}
  async support(a:Actor,key:string,existing?:{channelId:string;name:string;participants:string[];staff:Actor;maintenance?:boolean;openedAt?:number}){const now=this.clock();return this.store.change(s=>{if(existing?.maintenance){requireGroup(this.config,existing.staff,'owner',true);if(!s.maintenance||!s.initialized)throw new UserError('Legacy adoption requires an initialized bot in maintenance.');}else this.ensure(s);if(existing?.openedAt!==undefined&&(!Number.isSafeInteger(existing.openedAt)||existing.openedAt<0))throw new UserError('Invalid original opening time.');const c=this.config,kind=c.supportTicketTypes.find(t=>t.key===key&&t.enabled);if(!c.modules.supportTickets||!kind||!kind.categoryId||!kind.archiveChannelId)throw new UserError('This ticket type is unavailable.');if(!existing?.maintenance&&Object.values(s.tickets).some(t=>t.type===key&&t.opener===a.id&&t.status!=='closed'))throw new UserError('You already have a ticket of this type.');if(existing&&Object.values(s.tickets).some(t=>t.channelId===existing.channelId&&t.status!=='closed'))throw new UserError('This channel is already registered.');const p=player(s,a.id);const t:Ticket={id:randomUUID(),channelId:null,type:key,opener:a.id,region:p.region,openingTier:p.tier,openingIgn:p.ign,tester:null,target:null,passed:false,status:'opening',participants:[],openedAt:now,accessRoles:rolesFor(c,[...kind.accessGroups,'owner']),closingRoles:rolesFor(c,[...kind.closingGroups,'owner']),archiveChannelId:kind.archiveChannelId,copyImages:kind.copyImages,imageRetentionDays:c.archival.imageRetentionDays,archiveDirectory:c.archival.directory,minimumDeletionDelaySeconds:c.archival.minimumDeletionDelaySeconds,categoryId:kind.categoryId,name:channelName(`${key}-${a.id}`)};if(existing){t.channelId=existing.channelId;t.name=existing.name;t.participants=[...new Set(existing.participants)];t.openedAt=existing.openedAt??now;this.audit(s,existing.staff,existing.maintenance?'legacy-support-adopt':'set-ticket',t.id,now);}s.tickets[t.id]=t;enqueue(s,'open',{ticketId:t.id,...(existing?{adopt:true,preserveAccess:!!existing.maintenance,silentAdoption:!!existing.maintenance}:{})},now);return t;});}
  private ticket(s:State,id:string,a:Actor,group:'staff'|'regulator'='staff'):Ticket{requireGroup(this.config,a,group,true);const t=s.tickets[id];if(!t||t.status!=='open')throw new UserError('This ticket is not open.');return t;}
  async pass(a:Actor,id:string){const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=this.ticket(s,id,a);if(t.type!=='test'||t.target||t.passed)throw new UserError('This ticket cannot pass evaluation again.');t.passed=true;t.target='HT3';t.categoryId=this.config.categories.highTests!;t.name=channelName(`${t.openingDiscordUsername??t.openingNickname??t.openingIgn}-ht3-${t.region}`);const p=player(s,t.opener);p.tier='LT3';syncLists(s,p,now);this.jobs(s,p,now);enqueue(s,'notice',{ticketId:id,event:'passeval',content:`<@${a.id}> passed the evaluation for <@${p.id}>. LT3 has been assigned.`,mentions:[a.id,p.id]},now);this.audit(s,a,'passeval',id,now);});}
  async add(a:Actor,id:string,member:string,isTester:boolean){const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=this.ticket(s,id,a);if(member===t.opener||t.participants.includes(member)||member===t.tester)throw new UserError('This member already has recorded ticket access.');t.participants.push(member);if(t.type==='test'&&!t.tester&&isTester)t.tester=member;enqueue(s,'notice',{ticketId:id,event:'access',content:`Added <@${member}> to this ticket.`,mentions:[member]},now);this.audit(s,a,'add',`${id}:${member}`,now);});}
  async remove(a:Actor,id:string,member:string){return this.store.change(s=>{this.ensure(s);const t=this.ticket(s,id,a);if(t.opener===member||t.tester===member)throw new UserError('The opener and original tester cannot be removed.');t.participants=t.participants.filter(x=>x!==member);enqueue(s,'notice',{ticketId:id,event:'access',remove:member,content:`Removed <@${member}> from this ticket.`},this.clock());this.audit(s,a,'remove',`${id}:${member}`,this.clock());});}
  async rename(a:Actor,id:string,name:string){return this.store.change(s=>{this.ensure(s);const t=this.ticket(s,id,a);t.name=channelName(name);enqueue(s,'notice',{ticketId:id,event:'rename',content:`Ticket renamed to ${t.name}.`},this.clock());this.audit(s,a,'rename',id,this.clock());});}
  private requireCloser(a:Actor,t:Ticket){
    if(t.type==='test')requireGroup(this.config,a,'staff',true);else if(!a.channelAccess||(!allowed(this.config,a,'owner')&&!t.closingRoles.some(x=>a.roles.includes(x))))throw new UserError('Only the responsible staff can close this ticket.');
  }
  private finishClose(s:State,t:Ticket,a:Actor,outcome:Tier|'discontinued'|'skipped',reason:string,now:number){
    const id=t.id;
    for(const request of t.closeRequests??[])if(request.status==='pending'){request.status='cancelled';request.resolvedAt=now;enqueue(s,'notice',{ticketId:id,event:'close-request-update',requestId:request.id},now);}
      const p=player(s,t.opener);t.status='closing';t.closedAt=now;t.outcome=outcome;delete t.deadline;
      if(t.type==='test'){
        if(outcome==='discontinued'){p.tier=t.openingTier;syncLists(s,p,now);if(!restricted(s,p,now))for(const m of t.openingLists??[]){if(m.tier===p.tier&&listTiers.includes(m.tier)){s.lists[m.tier]??={};const list=s.lists[m.tier]![m.region]??=[];if(!list.includes(p.id))list.push(p.id);}}}
        else if(outcome!=='skipped'){p.tier=outcome;syncLists(s,p,now);p.cooldownUntil=now+milliseconds((t.target?this.config.testing.highCooldown:this.config.testing.normalCooldown)??'0');if(t.tester){s.completions.push({ticketId:id,tester:t.tester,at:now});t.creditApplied=true;}enqueue(s,'result',{ticketId:id},now);}
        this.jobs(s,p,now);
      }
      enqueue(s,'archive',{ticketId:id,actor:a.id,reason},now);this.audit(s,a,'close',id,now);
  }
  async close(a:Actor,id:string,outcome:Tier|'discontinued'|'skipped',reason=''){
    const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=s.tickets[id];if(!t||t.status!=='open')throw new UserError('This ticket is already closing or closed.');
      this.requireCloser(a,t);if(outcome==='skipped'&&(t.passed||t.type!=='test'))throw new UserError('This ticket cannot be skipped after evaluation.');
      this.finishClose(s,t,a,outcome,reason,now);
    });
  }
  async forceClose(a:Actor,id:string,reason:string){
    reason=reason.trim();if(!reason||reason.length>1000)throw new UserError('Provide a closure reason up to 1000 characters.');
    const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=s.tickets[id];if(!t||t.status!=='open')throw new UserError('This ticket is already closing or closed.');if(t.type==='test')throw new UserError('Use /close to finish or discontinue a testing ticket.');this.requireCloser(a,t);this.finishClose(s,t,a,'discontinued',reason,now);});
  }
  async requestClose(a:Actor,id:string,reason:string,timeout:string){
    reason=reason.trim();if(!reason||reason.length>1000)throw new UserError('Provide a reason up to 1000 characters.');const ms=milliseconds(timeout);if(ms<3600000||ms>7*86400000)throw new UserError('Timeout must be between 1h and 7d.');
    const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=s.tickets[id];if(!t||t.status!=='open')throw new UserError('This ticket is not open.');this.requireCloser(a,t);
      if(t.closeRequests?.some(r=>r.status==='pending'))throw new UserError('This ticket already has a pending closure request.');
      const r={id:randomUUID(),requestedBy:a.id,reason,requestedAt:now,expiresAt:now+ms,status:'pending' as const};(t.closeRequests??=[]).push(r);
      enqueue(s,'notice',{ticketId:id,event:'close-request',requestId:r.id},now);this.audit(s,a,'request-close',id,now);return r;
    });
  }
  async decideClose(a:Actor,id:string,requestId:string,accept:boolean){
    const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=s.tickets[id];if(!t||t.opener!==a.id||!a.channelAccess)throw new UserError('Only the ticket opener can answer this request.');
      const r=t.closeRequests?.find(r=>r.id===requestId);if(!r||r.status!=='pending'||t.status!=='open')throw new UserError('This closure request has already ended.');
      r.status=now>=r.expiresAt?'expired':accept?'accepted':'denied';r.resolvedAt=now;enqueue(s,'notice',{ticketId:id,event:'close-request-update',requestId:r.id},now);
      this.audit(s,a,`request-close-${r.status}`,id,now);if(r.status!=='denied')this.finishClose(s,t,a,'discontinued',r.reason,now);return r.status;
    });
  }
  async deadline(a:Actor,id:string,duration:string|null){const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=this.ticket(s,id,a,'regulator');if(duration===null){delete t.deadline;}else{const ms=milliseconds(duration);if(ms<60_000||ms>14*86_400_000)throw new UserError('Deadline must be between 1m and 14d.');t.deadline={at:now+ms,setter:a.id,notified:false};}enqueue(s,'notice',{ticketId:id,content:t.deadline?`⏳ Ticket Deadline\n<@${t.opener}> Deadline: <t:${Math.floor(t.deadline.at/1000)}:F> (<t:${Math.floor(t.deadline.at/1000)}:R>). Set by <@${a.id}>. Staff will review this ticket; it will not close automatically.`:`Deadline cleared by <@${a.id}>.`,mentions:[t.opener,a.id]},now);this.audit(s,a,duration?'deadline':'deadline-clear',id,now);});}
  async unverify(a:Actor,id:string){requireGroup(this.config,a,'botAdmin');const now=this.clock();return this.store.change(s=>{this.ensure(s);if(currentTicket(s,id))throw new UserError('Finish the open test first.');const p=player(s,id);Object.assign(p,{uuid:null,ign:null,region:null,preferredServer:null,waitlist:false});removeQueue(s,id);clearLists(s,id);this.jobs(s,p,now);this.audit(s,a,'unverify',id,now);});}
  async restriction(a:Actor,id:string,uuid:string,reason:string,duration:string|null){requireGroup(this.config,a,'restrictionKey');const now=this.clock();if(duration&&milliseconds(duration)===0)throw new UserError('Omit duration for an indefinite restriction.');return this.store.change(s=>{this.ensure(s);if(s.restrictions.some(r=>(r.playerId===id||r.uuid===uuid)&&(r.until===null||r.until>now)))throw new UserError('This account already has a restriction.');if(!reason.trim()||reason.length>1000)throw new UserError('Provide a reason up to 1000 characters.');s.restrictions.push({id:randomUUID(),playerId:id,uuid,reason,until:duration?now+milliseconds(duration):null,actor:a.id,previousTier:player(s,id).tier});removeQueue(s,id);clearLists(s,id);this.jobs(s,player(s,id),now);this.audit(s,a,'restrict',id,now);});}
  async unrestrict(a:Actor,id:string){requireGroup(this.config,a,'restrictionKey');const now=this.clock();return this.store.change(s=>{this.ensure(s);const removed=s.restrictions.filter(r=>r.playerId===id);s.restrictions=s.restrictions.filter(r=>r.playerId!==id);const target=s.players[id],previous=[...removed].reverse().find(r=>r.previousTier!==undefined)?.previousTier;if(target&&previous!==undefined)target.tier=previous;for(const p of Object.values(s.players))if(p.id===id||removed.some(r=>r.uuid===p.uuid))enqueue(s,'roles',{playerId:p.id},now);this.audit(s,a,'unrestrict',id,now);});}
  async list(a:Actor,tier:Tier,action:'add'|'remove',id:string,region:string){requireGroup(this.config,a,'listAdmin');const r=this.region(region),now=this.clock();return this.store.change(s=>{this.ensure(s);if(!this.config.modules.tierLists||!listTiers.includes(tier))throw new UserError('Tier lists are disabled or invalid.');const p=player(s,id);if(action==='add'){if(p.tier!==tier||restricted(s,p,now))throw new UserError('Member must hold this tier and be unrestricted.');s.lists[tier]??={};const list=s.lists[tier]![r]??=[];if(!list.includes(id))list.push(id);}else if(s.lists[tier]?.[r])s.lists[tier]![r]=s.lists[tier]![r]!.filter(x=>x!==id);enqueue(s,'lists',{},now);this.audit(s,a,`${tier}list-${action}`,id,now);});}
  async forceResult(a:Actor,id:string,tier:Tier,region:string,ign?:string,source?:string){requireGroup(this.config,a,'regulator');const r=this.region(region),now=this.clock();return this.store.change(s=>{this.ensure(s);if(currentTicket(s,id))throw new UserError('Finish the existing test first.');const p=player(s,id),previousTier=p.tier;p.tier=tier;p.region=r;if(ign&&!p.uuid)p.ign=ign;removeQueue(s,id);syncLists(s,p,now);this.jobs(s,p,now);enqueue(s,'result',{playerId:id,previousTier,earnedTier:tier,ign:p.ign,region:r,actor:a.id,source:source??'Forced result'},now);this.audit(s,a,source?'migrate':'forceresult',id,now);});}
  async forceTest(a:Actor,id:string,region:string){requireGroup(this.config,a,'regulator');const r=this.region(region),now=this.clock();return this.store.change(s=>{this.testing(s);const p=player(s,id);this.eligible(s,p,now,true);if(p.region!==r)throw new UserError('Use the player’s registered region.');if(p.tier==='HT1')throw new UserError('make a general support ticket to address rank defenses or retirement');return this.open(s,p,null,highTarget[p.tier]??null,now);});}
  async stopQueue(a:Actor,region:string){requireGroup(this.config,a,'regulator');const r=this.region(region);return this.store.change(s=>{this.ensure(s);for(const id of Object.keys(s.testers))if(s.testers[id]===r)delete s.testers[id];s.queues[r]=[];enqueue(s,'queues',{},this.clock());});}
  async resetCooldown(a:Actor,id:string){if(!allowed(this.config,a,'cdResetter'))requireGroup(this.config,a,'botAdmin');return this.writeCooldown(a,id,0);}
  async cooldown(a:Actor,id:string,days:number){requireGroup(this.config,a,'botAdmin');return this.writeCooldown(a,id,days);}
  private async writeCooldown(a:Actor,id:string,days:number){if(!Number.isFinite(days)||days<0||days>3650)throw new UserError('Invalid number of days.');return this.store.change(s=>{this.ensure(s);player(s,id).cooldownUntil=days?this.clock()+days*86_400_000:0;this.audit(s,a,'cooldown',id,this.clock());});}
  async maintenance(a:Actor,on:boolean){requireGroup(this.config,a,'owner');return this.store.change(s=>{s.maintenance=on;if(on)s.testers={};enqueue(s,'queues',{},this.clock());this.audit(s,a,'maintenance',String(on),this.clock());});}
  async reset(a:Actor,id:string){requireGroup(this.config,a,'owner');return this.store.change(s=>{this.ensure(s);if(currentTicket(s,id))throw new UserError('Finish the existing test first.');delete s.players[id];const p=player(s,id);removeQueue(s,id);clearLists(s,id);this.jobs(s,p,this.clock());this.audit(s,a,'reset',id,this.clock());});}
  async resetAllCooldowns(a:Actor){requireGroup(this.config,a,'owner');return this.store.change(s=>{this.ensure(s);for(const p of Object.values(s.players))p.cooldownUntil=0;this.audit(s,a,'reset-all-cooldowns','all',this.clock());});}
  async adopt(a:Actor,channelId:string,key:string,opener:string,tester:string|null,name:string,participants:string[],options:{maintenance?:boolean;openedAt?:number}={}){
    requireGroup(this.config,a,'staff',true);const now=this.clock();
    if(key==='test'&&options.maintenance)throw new UserError('Testing ticket imports require reviewed migration metadata.');
    if(key==='test'&&!tester)throw new UserError('Specify the original tester.');
    if(key==='test')return this.store.change(s=>{this.testing(s);if(Object.values(s.tickets).some(t=>t.channelId===channelId&&t.status!=='closed'))throw new UserError('This channel is already registered.');const p=player(s,opener);this.eligible(s,p,now);const t=this.open(s,p,tester,highTarget[p.tier]??null,now);t.channelId=channelId;t.name=name;t.participants=[...new Set([...participants,...(tester?[tester]:[])])];this.audit(s,a,'set-ticket',t.id,now);return t;});
    return this.support({...a,id:opener},key,{channelId,name,participants,staff:a,...options});
  }
  async changeType(a:Actor,id:string,key:string,tester:string|null){const now=this.clock();return this.store.change(s=>{this.ensure(s);const t=this.ticket(s,id,a),c=this.config,previousRoles=[...t.accessRoles];
    if(t.type==='test'){if(key!=='high')throw new UserError('Testing cannot be converted to a support type.');t.target??='HT3';t.categoryId=c.categories.highTests!;}
    else if(key==='test'){if(!tester)throw new UserError('Specify the original tester.');this.testing(s);const p=player(s,t.opener);this.eligible(s,p,now);t.type='test';t.tester=tester;t.region=p.region;t.openingTier=p.tier;t.openingIgn=p.ign;t.target=highTarget[p.tier]??null;t.categoryId=t.target?c.categories.highTests!:c.regions[p.region!].testCategoryId!;t.archiveChannelId=c.channels.testingArchives!;t.copyImages=false;t.accessRoles=rolesFor(c,['staff','owner']);t.closingRoles=[...t.accessRoles];if(!t.participants.includes(tester))t.participants.push(tester);removeQueue(s,p.id);}
    else{const kind=c.supportTicketTypes.find(x=>x.enabled&&x.key===key);if(!c.modules.supportTickets||!kind)throw new UserError('This ticket type is unavailable.');if(Object.values(s.tickets).some(x=>x.id!==id&&x.opener===t.opener&&x.type===key&&x.status!=='closed'))throw new UserError('This player already has a ticket of that type.');t.type=key;t.categoryId=kind.categoryId!;t.archiveChannelId=kind.archiveChannelId!;t.copyImages=kind.copyImages;t.accessRoles=rolesFor(c,[...kind.accessGroups,'owner']);t.closingRoles=rolesFor(c,[...kind.closingGroups,'owner']);}
    enqueue(s,'notice',{ticketId:id,event:'type',previousRoles,content:`Ticket type changed by <@${a.id}>.`,mentions:[a.id]},now);this.audit(s,a,'changeticket',id,now);
  });}
  async tick(){const now=this.clock();return this.store.change(s=>{if(!s.maintenance)for(const t of Object.values(s.tickets))if(t.status==='open')for(const r of t.closeRequests??[])if(r.status==='pending'&&r.expiresAt<=now){r.status='expired';r.resolvedAt=now;enqueue(s,'notice',{ticketId:t.id,event:'close-request-update',requestId:r.id},now);this.finishClose(s,t,{id:'system',roles:[],channelAccess:true,administrator:false},'discontinued',r.reason,now);break;}for(const t of Object.values(s.tickets))if(t.status==='open'&&t.deadline&&!t.deadline.notified&&t.deadline.at<=now){enqueue(s,'deadline',{ticketId:t.id,setter:t.deadline.setter,at:t.deadline.at},now);t.deadline.notified=true;}const expired=s.restrictions.filter(r=>r.until!==null&&r.until<=now);s.restrictions=s.restrictions.filter(r=>r.until===null||r.until>now);for(const r of expired)this.audit(s,{id:'system',roles:[],administrator:false},'restriction-expired',r.playerId,now);for(const p of Object.values(s.players))if(expired.some(r=>r.playerId===p.id||r.uuid===p.uuid)){const previous=[...expired].reverse().find(r=>r.playerId===p.id&&r.previousTier!==undefined)?.previousTier;if(previous!==undefined)p.tier=previous;enqueue(s,'roles',{playerId:p.id},now);}});}
}
